package com.example.demo.dto;

public enum Transaction_type {
	Credited_to_wallet,Debited_from_wallet;
}
