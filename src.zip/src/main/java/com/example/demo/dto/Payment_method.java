package com.example.demo.dto;

public enum Payment_method {
	Credit_Card,Debit_Card,Google_pay,Amazon_pay,PhonePe,Paytm,Bank_Transfer;
}
