package com.example.demo.dto;

public enum Payment_status {
	Success,Failed;
}
