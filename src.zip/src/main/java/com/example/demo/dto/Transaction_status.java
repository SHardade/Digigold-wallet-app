package com.example.demo.dto;

public enum Transaction_status {
	Success,Failed
}
