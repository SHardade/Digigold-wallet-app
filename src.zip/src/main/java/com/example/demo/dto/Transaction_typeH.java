package com.example.demo.dto;

public enum Transaction_typeH {
	Buy,Sell,Convert_to_physical;
}
